const express = require('express');
const mysql = require('mysql2');
const app = express();

// MySQL connection configuration
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'catchtha1',
    database: 'catchtha1',
    password: 'DOWNLOAD@2290'
});

// Check MySQL connection
connection.connect(err => {
    if (err) {
        console.error('Error connecting to MySQL database:', err);
        return;
    }
    console.log('Connected to MySQL database');
});

app.get('/', (request, response) => {
    // Call the query to retrieve data from the users table
    connection.query('SELECT * FROM `users`', (err, results) => {
        if (err) {
            console.error('Error executing MySQL query:', err);
            response.status(500).send('Error retrieving data from the database');
            return;
        }

        // Send the retrieved data as response
        response.send(`
            <h1>Status Code: ${response.statusCode}</h1>
            <h2>Hello World</h2>
            <pre>${JSON.stringify(results)}</pre>
        `);
    });
});

app.listen(3003, () => {
    console.log(`App is listening on http://localhost:3003`);
});
